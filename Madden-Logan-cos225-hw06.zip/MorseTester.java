public class MorseTester {
    
}
